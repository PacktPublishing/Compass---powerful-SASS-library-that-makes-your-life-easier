css_dir = "css"
sass_dir = "scss"
images_dir = "img"
relative_assets = true;
